# Real-Time YOLO + Optical Flow — Google Colab

Open `Real_Time_YOLO_Optical_Flow_Colab.ipynb` in Google Colab.

1. Enable a GPU.
2. Run cells in order.
3. Upload a 20–60 second pedestrian/traffic MP4.
4. The notebook runs YOLO detection and Lucas–Kanade optical flow.
5. It reports FPS, latency, detected persons, and average optical-flow displacement.
6. It creates and downloads `yolo_optical_flow_result.mp4`.

For benchmark-style data, MOT17 is a suitable source. The first prototype intentionally uses a short uploaded video so Colab does not need the full MOT17 release.
